package com.example.registrationform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
